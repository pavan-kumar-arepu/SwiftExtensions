import UIKit

var str = "Hello, Here we will learn Swift Extensions!!!"

//Syntax:

/*
extension ClassStructEnumOrProtocolNameGoesHere {
    //add functionality to the above type
}
 */


//Extending 'Integer'
extension Int {
    var square: Int{
        return self * self
    }
    
    func cube()->Int {
     return self * self * self
    }

    mutating func incrementBy5() {
            self = self + 5
    }
}
var x : Int = 10
print(x.square)
print(x.cube())
x.incrementBy5()

//Extending 'String'

extension String {
    var length: Int {
        get {
            return self.count
        }
    }
    
    mutating func addString(str: String){
    self = self + str
    }
}

var sampleString = "Hello"
print("Length of the Given String : \(sampleString.length)")
sampleString.length
sampleString.addString(str: "_iOS_Sprinter")
sampleString.length

//Exmaple for Convenience Initializer in 'Classes'

class A {
    var name : String
    var age : Int
    
    init (name: String)
    {
        self.name = name
        self.age = 33
    }
}

extension A {
    convenience init(name: String, age: Int) {
        self.init(name:name)
    }
}


var a = A(name:"Kumar")
var b = A(name:"Arepu",age:32)

print (a.name)
print (a.age)

print (b.name)
print (b.age)

//Extensions in 'Structures'

//Structs create the default initialisers with all the properties for us as shown below:


struct iOSStruct {
    
    var name : String
    var age : Int
    
}
var s = iOSStruct(name: "Kumar", age: 33)
print(s.name)
print(s.age)



//Once we define our own initializer, Swift forbids us from using the above default initialiser
struct newStruct {
    
    var name : String
    var age : Int
    
  
}

extension newStruct {
        init(age : Int) {
              self.age = age
              self.name = "JaiSriRam"
          }
}

var newS = newStruct(age: 1)
var newS1 = newStruct( age:234)
var newS2 = newStruct(name: "JaiHanuman", age: 1234)

newS.name
newS.age
newS1.name
newS1.age
newS2.name
newS2.age
